//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WatchCom.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WATCHCOM_DIALOG             102
#define IDS_COMA                        102
#define IDS_COMB                        103
#define IDM_COMA                        104
#define IDM_COMB                        105
#define IDM_CLEARLOG                    106
#define IDS_CLEARLOG                    107
#define IDS_COMC                        108
#define IDS_COMD                        109
#define IDM_COMC                        110
#define IDM_COMD                        111
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDC_STATIC_COMA                 1004
#define IDC_STATIC_COMB                 1005
#define IDC_BUTTON_A                    1006
#define IDC_STATIC_COMC                 1006
#define IDC_BUTTON_B                    1007
#define IDC_STATIC_COMD                 1007
#define IDC_RICHEDIT1                   1009
#define IDC_RADIO_BAUD600               1010
#define IDC_RADIO_BAUD1200              1011
#define IDC_RADIO_BAUD1800              1012
#define IDC_RADIO_BAUD2400              1013
#define IDC_RADIO_BAUD4800              1014
#define IDC_RADIO_BAUD7200              1015
#define IDC_RADIO_BAUD9600              1016
#define IDC_RADIO_BAUD14400             1017
#define IDC_RADIO_BAUD19200             1018
#define IDC_RADIO_BAUD38400             1019
#define IDC_RADIO_BAUD56000             1020
#define IDC_RADIO_BAUD57600             1021
#define IDC_RADIO_BAUD115200            1022
#define IDC_RADIO_BAUD128000            1023
#define IDC_RADIO15                     1024
#define IDC_RADIO16                     1025
#define IDC_RADIO17                     1026
#define IDC_RADIO18                     1027
#define IDC_RADIO19                     1028
#define IDC_RADIO20                     1029
#define IDC_RADIO21                     1030
#define IDC_RADIO22                     1031
#define IDC_RADIO23                     1032
#define IDC_RADIO24                     1033
#define IDC_RADIO25                     1034
#define IDC_RADIO26                     1035
#define IDC_LIST1                       1036
#define IDC_RADIO_BAUD300               1037
#define IDC_BUTTON_CLEAR                1039
#define IDC_BUTTON_SAVE                 1040
#define IDC_DESTINATIONNAME_EDIT        1041
#define IDC_BUTTON_BROWSE               1042
#define IDC_EDIT_LONGNAME               1043
#define IDC_STATIC_EXAMPLE              1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
