// WatchComDlg.h : header file
//
#include "serial.h"

#if !defined(AFX_WATCHCOMDLG_H__335375D6_DAF8_11D2_B4B7_006008A70A6A__INCLUDED_)
#define AFX_WATCHCOMDLG_H__335375D6_DAF8_11D2_B4B7_006008A70A6A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CWatchComDlg dialog
#define RESIZETIMER 1000

class CWatchComDlg : public CDialog
{
// Construction
public:
	CWatchComDlg(CWnd* pParent = NULL);	// standard constructor
	~CWatchComDlg();
// Dialog Data
	//{{AFX_DATA(CWatchComDlg)
	enum { IDD = IDD_WATCHCOM_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWatchComDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void ResizeChildren();
	CRect m_WindowRect;
	HICON m_hIcon;
	CSerial *ComA;
	CSerial *ComB;
	CSerial *ComC;
	CSerial *ComD;
	char m_szIniFile[_MAX_PATH];
	char m_szAPort[16];
	char m_szBPort[16];
	char m_szCPort[16];
	char m_szDPort[16];
	char m_szAParity[16];
	char m_szBParity[16];
	char m_szCParity[16];
	char m_szDParity[16];
	int m_dABaudRate;
	int m_dBBaudRate;
	int m_dCBaudRate;
	int m_dDBaudRate;
	int m_dADataBits;
	int m_dBDataBits;
	int m_dCDataBits;
	int m_dDDataBits;
	int m_dAStopBits;
	int m_dBStopBits;
	int m_dCStopBits;
	int m_dDStopBits;
	char m_szADestination[_MAX_PATH];
	char m_szBDestination[_MAX_PATH];
	char m_szCDestination[_MAX_PATH];
	char m_szDDestination[_MAX_PATH];
	char m_szAFileName[_MAX_PATH];
	char m_szBFileName[_MAX_PATH];
	char m_szCFileName[_MAX_PATH];
	char m_szDFileName[_MAX_PATH];
	bool m_bANewLine;
	bool m_bBNewLine;
	bool m_bCNewLine;
	bool m_bDNewLine;
	int m_iPreviousDay;
	char m_cAPreviousChar;
	char m_cBPreviousChar;
	char m_cCPreviousChar;
	char m_cDPreviousChar;
	COLORREF m_iAColor;
	COLORREF m_iBColor;
	COLORREF m_iCColor;
	COLORREF m_iDColor;
	// Generated message map functions
	//{{AFX_MSG(CWatchComDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnReceive(WPARAM WParam, LPARAM LParam);
	afx_msg void OnReceiveA(WPARAM WParam, LPARAM LParam);
	afx_msg void OnReceiveB(WPARAM WParam, LPARAM LParam);
	afx_msg void OnReceiveC(WPARAM WParam, LPARAM LParam);
	afx_msg void OnReceiveD(WPARAM WParam, LPARAM LParam);
	afx_msg void OnButtonClear();
	afx_msg void OnButtonSave();
	afx_msg void OnButtonA();
	afx_msg void OnButtonB();
	afx_msg void OnButtonC();
	afx_msg void OnButtonD();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSizing(UINT nSide, LPRECT lpRect);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WATCHCOMDLG_H__335375D6_DAF8_11D2_B4B7_006008A70A6A__INCLUDED_)
