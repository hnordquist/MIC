// WatchComDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WatchCom.h"
#include "WatchComDlg.h"
#include "Select.h"
#include "serial.h"
#include "DirDialog.h"
#include  <io.h>
#include <afxdisp.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define IDC_RECEIVE                     10100
#define IDC_RECEIVEA					10101
#define IDC_RECEIVEB					10102
#define IDC_RECEIVEC					10103
#define IDC_RECEIVED					10104



/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWatchComDlg dialog

CWatchComDlg::CWatchComDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWatchComDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWatchComDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	ComA = NULL;
	ComB = NULL;
	ComC = NULL;
	ComD = NULL;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_iPreviousDay = 32;
}

void CWatchComDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWatchComDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWatchComDlg, CDialog)
	//{{AFX_MSG_MAP(CWatchComDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(IDC_RECEIVEA,OnReceiveA)
	ON_MESSAGE(IDC_RECEIVEB,OnReceiveB)
	ON_MESSAGE(IDC_RECEIVEC,OnReceiveC)
	ON_MESSAGE(IDC_RECEIVED,OnReceiveD)
	ON_WM_CTLCOLOR()
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//	ON_BN_CLICKED(IDC_BUTTON_A, OnButtonA)
//	ON_BN_CLICKED(IDC_BUTTON_B, OnButtonB)
//	ON_BN_CLICKED(IDC_BUTTON_C, OnButtonA)
//	ON_BN_CLICKED(IDC_BUTTON_D, OnButtonB)
//	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
//	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)

/////////////////////////////////////////////////////////////////////////////
// CWatchComDlg message handlers

BOOL CWatchComDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		CString strComA;
		CString strComB;
		CString strComC;
		CString strComD;
		CString strClearLog;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		strComA.LoadString(IDS_COMA);
		strComB.LoadString(IDS_COMB);
		strComC.LoadString(IDS_COMC);
		strComD.LoadString(IDS_COMD);
		strClearLog.LoadString(IDS_CLEARLOG);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_COMA,strComA);
			pSysMenu->AppendMenu(MF_STRING, IDM_COMB,strComB);
			pSysMenu->AppendMenu(MF_STRING, IDM_COMC,strComC);
			pSysMenu->AppendMenu(MF_STRING, IDM_COMD,strComD);
			pSysMenu->AppendMenu(MF_STRING, IDM_CLEARLOG,strClearLog);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	GetWindowRect(&m_WindowRect);
	ClientToScreen(&m_WindowRect);

	m_bANewLine = true;
	m_bBNewLine = true;
	m_bCNewLine = true;
	m_bDNewLine = true;

	//build the ini file name
	//get full path and name for this instance of application
	GetModuleFileName(AfxGetInstanceHandle(),m_szIniFile,sizeof(m_szIniFile));
	char *c = strrchr(m_szIniFile,'.');//find the last "."
	*c = '\0';						//make it null
	strcat(m_szIniFile,".INI");
	//if the ini file isn't there create a "default" one
	if (access(m_szIniFile,0)!=0)
	{
		FILE* temp;
		if ((temp = fopen(m_szIniFile,"wt"))!=NULL)
		{
			fprintf(temp,"[COM_A]\n");
			fprintf(temp,"BAUD=9600\n");
			fprintf(temp,"PORT=\n");
			fprintf(temp,"DATABITS=8\n");
			fprintf(temp,"STOPBITS=1\n");
			fprintf(temp,"PARITY=NONE\n");
			fprintf(temp,"FILENAME=AA%%P_%%y%%m%%d.log\n");
			fprintf(temp,"FILELOCATION=C:\\\n");
			fprintf(temp,"COLOR_RGB=0,0,0\n\n");

			fprintf(temp,"[COM_B]\n");
			fprintf(temp,"BAUD=9600\n");
			fprintf(temp,"PORT=\n");
			fprintf(temp,"DATABITS=8\n");
			fprintf(temp,"STOPBITS=1\n");
			fprintf(temp,"PARITY=NONE\n");
			fprintf(temp,"FILENAME=AA%%P_%%y%%m%%d.log\n");
			fprintf(temp,"FILELOCATION=C:\\\n");
			fprintf(temp,"COLOR_RGB=191,0,0\n\n");

			fprintf(temp,"[COM_C]\n");
			fprintf(temp,"BAUD=9600\n");
			fprintf(temp,"PORT=\n");
			fprintf(temp,"DATABITS=8\n");
			fprintf(temp,"STOPBITS=1\n");
			fprintf(temp,"PARITY=NONE\n");
			fprintf(temp,"FILENAME=AA%%P_%%y%%m%%d.log\n");
			fprintf(temp,"FILELOCATION=C:\\\n");
			fprintf(temp,"COLOR_RGB=0,191,0\n\n");

			fprintf(temp,"[COM_D]\n");
			fprintf(temp,"BAUD=9600\n");
			fprintf(temp,"PORT=\n");
			fprintf(temp,"DATABITS=8\n");
			fprintf(temp,"STOPBITS=1\n");
			fprintf(temp,"PARITY=NONE\n");
			fprintf(temp,"FILENAME=AA%%P_%%y%%m%%d.log\n");
			fprintf(temp,"FILELOCATION=C:\\\n");
			fprintf(temp,"COLOR_RGB=0,0,255\n");

			fclose(temp);
		}
	}

	GetPrivateProfileString("COM_A","PORT","",m_szAPort,sizeof(m_szAPort),m_szIniFile);
	char szTemp[64];
	GetPrivateProfileString("COM_A","PARITY","NONE",m_szAParity,sizeof(m_szAParity),m_szIniFile);
	m_dABaudRate = GetPrivateProfileInt("COM_A","BAUD",9600,m_szIniFile);
	m_dADataBits = GetPrivateProfileInt("COM_A","DATABITS",8,m_szIniFile);
	m_dAStopBits = GetPrivateProfileInt("COM_A","STOPBITS",1,m_szIniFile);
	GetPrivateProfileString("COM_A","FILENAME","",m_szAFileName,sizeof(m_szAFileName),m_szIniFile);
	GetPrivateProfileString("COM_A","FILELOCATION","C:\\",m_szADestination,sizeof(m_szADestination),m_szIniFile);
	GetPrivateProfileString("COM_A","COLOR_RGB","0,0,0",szTemp,sizeof(szTemp),m_szIniFile);
	int iRed,iGreen,iBlue;
	sscanf(szTemp,"%d,%d,%d",&iRed,&iGreen,&iBlue);
	m_iAColor = RGB(iRed,iGreen,iBlue);
	if (strlen(m_szAPort) > 0)
	{

		ComA = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		sprintf(szTemp,"Com A: %s, %d, %d, %d, %s",
			m_szAPort,
			m_dABaudRate,
			m_dADataBits,
			m_dAStopBits,
			m_szAParity);

		if (ComA->SetUpPort(m_szAPort,m_dABaudRate,
				m_dADataBits, m_dAStopBits, m_szAParity))
		{
			//connect to it
			ComA->DoSetMessage(1);
			ComA->Register(this);
			ComA->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMA,szTemp);
		}
		else
		{
			CString st("Could not set up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComA->DoStop();
			//get the com object to kill itself
			ComA->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComA->m_hThread,1000);
	//		TerminateThread(ComA->m_hThread,0);
			delete ComA;
			ComA = NULL;

//			MessageBox(st,"WatchCom",MB_OK);
			SetDlgItemText(IDC_STATIC_COMA,"Com A: FAILED");
		}
	}

	GetPrivateProfileString("COM_B","PORT","",m_szBPort,sizeof(m_szBPort),m_szIniFile);
	GetPrivateProfileString("COM_B","PARITY","NONE",m_szBParity,sizeof(m_szBParity),m_szIniFile);
	m_dBBaudRate = GetPrivateProfileInt("COM_B","BAUD",9600,m_szIniFile);
	m_dBDataBits = GetPrivateProfileInt("COM_B","DATABITS",8,m_szIniFile);
	m_dBStopBits = GetPrivateProfileInt("COM_B","STOPBITS",1,m_szIniFile);
	GetPrivateProfileString("COM_B","FILENAME","",m_szBFileName,sizeof(m_szBFileName),m_szIniFile);
	GetPrivateProfileString("COM_B","FILELOCATION","C:\\",m_szBDestination,sizeof(m_szBDestination),m_szIniFile);
	GetPrivateProfileString("COM_B","COLOR_RGB","191,0,0",szTemp,sizeof(szTemp),m_szIniFile);
	sscanf(szTemp,"%d,%d,%d",&iRed,&iGreen,&iBlue);
	m_iBColor = RGB(iRed,iGreen,iBlue);
	if (strlen(m_szBPort) > 0)
	{

		ComB = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		sprintf(szTemp,"Com B: %s, %d, %d, %d, %s",
			m_szBPort,
			m_dBBaudRate,
			m_dBDataBits,
			m_dBStopBits,
			m_szBParity);

		if (ComB->SetUpPort(m_szBPort,m_dBBaudRate,
				m_dBDataBits, m_dBStopBits, m_szBParity))
		{
			//connect to it
			ComB->DoSetMessage(2);
			ComB->Register(this);
			ComB->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMB,szTemp);
		}
		else
		{
			CString st("Could not set up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComB->DoStop();
			//get the com object to kill itself
			ComB->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComB->m_hThread,1000);
			delete ComB;
			ComB = NULL;

			SetDlgItemText(IDC_STATIC_COMB,"Com B: FAILED");
		}
	}

	GetPrivateProfileString("COM_C","PORT","",m_szCPort,sizeof(m_szCPort),m_szIniFile);
	GetPrivateProfileString("COM_C","PARITY","NONE",m_szCParity,sizeof(m_szCParity),m_szIniFile);
	m_dCBaudRate = GetPrivateProfileInt("COM_C","BAUD",9600,m_szIniFile);
	m_dCDataBits = GetPrivateProfileInt("COM_C","DATABITS",8,m_szIniFile);
	m_dCStopBits = GetPrivateProfileInt("COM_C","STOPBITS",1,m_szIniFile);
	GetPrivateProfileString("COM_C","FILENAME","",m_szCFileName,sizeof(m_szCFileName),m_szIniFile);
	GetPrivateProfileString("COM_C","FILELOCATION","C:\\",m_szCDestination,sizeof(m_szCDestination),m_szIniFile);
	GetPrivateProfileString("COM_C","COLOR_RGB","0,191,0",szTemp,sizeof(szTemp),m_szIniFile);
	sscanf(szTemp,"%d,%d,%d",&iRed,&iGreen,&iBlue);
	m_iCColor = RGB(iRed,iGreen,iBlue);
	if (strlen(m_szCPort) > 0)
	{

		ComC = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		sprintf(szTemp,"Com C: %s, %d, %d, %d, %s",
			m_szCPort,
			m_dCBaudRate,
			m_dCDataBits,
			m_dCStopBits,
			m_szCParity);

		if (ComC->SetUpPort(m_szCPort,m_dCBaudRate,
				m_dCDataBits, m_dCStopBits, m_szCParity))
		{
			//connect to it
			ComC->DoSetMessage(3);
			ComC->Register(this);
			ComC->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMC,szTemp);
		}
		else
		{
			CString st("Could not set up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComC->DoStop();
			//get the com object to kill itself
			ComC->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComC->m_hThread,1000);
			delete ComC;
			ComC = NULL;

			SetDlgItemText(IDC_STATIC_COMC,"Com C: FAILED");
		}
	}

	GetPrivateProfileString("COM_D","PORT","",m_szDPort,sizeof(m_szDPort),m_szIniFile);
	GetPrivateProfileString("COM_D","PARITY","NONE",m_szDParity,sizeof(m_szDParity),m_szIniFile);
	m_dDBaudRate = GetPrivateProfileInt("COM_D","BAUD",9600,m_szIniFile);
	m_dDDataBits = GetPrivateProfileInt("COM_D","DATABITS",8,m_szIniFile);
	m_dDStopBits = GetPrivateProfileInt("COM_D","STOPBITS",1,m_szIniFile);
	GetPrivateProfileString("COM_D","FILENAME","",m_szDFileName,sizeof(m_szDFileName),m_szIniFile);
	GetPrivateProfileString("COM_D","FILELOCATION","C:\\",m_szDDestination,sizeof(m_szDDestination),m_szIniFile);
	GetPrivateProfileString("COM_D","COLOR_RGB","0,0,255",szTemp,sizeof(szTemp),m_szIniFile);
	sscanf(szTemp,"%d,%d,%d",&iRed,&iGreen,&iBlue);
	m_iDColor = RGB(iRed,iGreen,iBlue);
	if (strlen(m_szDPort) > 0)
	{

		ComD = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		sprintf(szTemp,"Com D: %s, %d, %d, %d, %s",
			m_szDPort,
			m_dDBaudRate,
			m_dDDataBits,
			m_dDStopBits,
			m_szDParity);

		if (ComD->SetUpPort(m_szDPort,m_dDBaudRate,
				m_dDDataBits, m_dDStopBits, m_szDParity))
		{
			//connect to it
			ComD->DoSetMessage(4);
			ComD->Register(this);
			ComD->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMD,szTemp);
		}
		else
		{
			CString st("Could not set up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComD->DoStop();
			//get the com object to kill itself
			ComD->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComD->m_hThread,1000);
			delete ComD;
			ComD = NULL;

			SetDlgItemText(IDC_STATIC_COMD,"Com D: FAILED");
		}
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWatchComDlg::OnReceive(WPARAM WParam, LPARAM LParam)
{
	char hex[] = "0123456789ABCDEF";
	//make tbuff point to LParam
	char* tbuff = (char*)LParam;
	//create an "exchange" buffer to receive the data
	char  xbuff[2048];
	//j is index into xbuff
	int j = 0;
	
	//convert to displayable in CEdit
	for (unsigned int i = 0; i < WParam; i++)
	{
		xbuff[j++] = tbuff[i];
//		if ( ( (tbuff[i]&0x7f) == 0x0d) || ((tbuff[i]&0x7f) == 0x0a))
//		{
//				xbuff[j++] = 0x0d;
//				xbuff[j++] = 0x0a;
//		}
//		else 
//		{
//			if (isprint(tbuff[i]&0x7f))
//				xbuff[j++] = tbuff[i] & 0x7f;
//			else
//			{
//				xbuff[j++] = '{';
//				xbuff[j++] = hex[(tbuff[i] & 0xf0)>>4];
//				xbuff[j++] = hex[tbuff[i] & 0x0f];
//				xbuff[j++] = '}';
//			}
//		}
	}
	//terminate the character buffer 
	xbuff[j] = NULL;
	//increment the count of number of char in the cedit

	//select the end of the cedit (insertion point)
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(-2,-1);
	//append the new data
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->ReplaceSel(xbuff,false);

	delete [] (char*)LParam;
}

void
CWatchComDlg::OnReceiveA(WPARAM WParam, LPARAM LParam)
{
	CString cResult;
	CString cTemp;
	CString cFormat;
	COleDateTime cNow = COleDateTime::GetCurrentTime();
	if (cNow.GetDay() < m_iPreviousDay)
	{
		OnButtonClear();
		m_iPreviousDay = cNow.GetDay();
	}

	cFormat = m_szAFileName;
	bool bHaveEscape;
	bHaveEscape = false;
	int i;
	if (strlen(m_szAFileName))
	{
		for (int iSourceIndex = 0; iSourceIndex < cFormat.GetLength(); iSourceIndex++)
		{
			if ((cFormat[iSourceIndex]=='%') && (!bHaveEscape))
				bHaveEscape = true;
			else if (bHaveEscape)
			{
				bHaveEscape = false;
				switch (cFormat[iSourceIndex]) {
				case 'P':
					for (i = 0; i < (int)strlen(m_szAPort); i++)
						if ((m_szAPort[i] >=0)  && (m_szAPort[i] <= '9')) cResult += m_szAPort[i];
					break;
				case 'y':
					cTemp.Format("%04d",cNow.GetYear());
					cResult += cTemp;
					break;
				case 'm':
					cTemp.Format("%02d",cNow.GetMonth());
					cResult += cTemp;
					break;
				case 'd':
					cTemp.Format("%02d",cNow.GetDay());
					cResult += cTemp;
					break;
				case 'H':
					cTemp.Format("%02d",cNow.GetHour());
					cResult += cTemp;
					break;
				case 'M':
					cTemp.Format("%02d",cNow.GetMinute());
					cResult += cTemp;
					break;
				case 'S':
					cTemp.Format("%02d",cNow.GetSecond());
					cResult += cTemp;
					break;
				default:
					cResult += cFormat[iSourceIndex];
				}
			}
			else
				cResult += cFormat[iSourceIndex];
		}

		if (cResult.FindOneOf("\\/?*:;><\"")<0)
		{
			CString cFilePathName;
			cFilePathName = m_szADestination;
			cFilePathName += cResult;
			FILE * outfile = fopen(cFilePathName,"at");
			if (outfile)
			{
				for (int i = 0; i < (int)WParam; i++)
				{
					if (m_bANewLine)
					{
						m_bANewLine = false;
						fprintf(outfile,"%s ",cNow.Format("%Y\\%m\\%d %H:%M:%S"));
					}
					char ch = (*((char*)LParam+i));
					if ((m_cAPreviousChar == 0x0d) && (ch != 0x0a)) 
						fputc(0x0a,outfile);
					fputc(ch,outfile);
					if (ch == 0x0A) m_bANewLine = true;
					m_cAPreviousChar = ch;
				}
				fclose(outfile);
			}
		}

	}

	CHARFORMAT cf;
	cf.cbSize=sizeof(cf);
	cf.dwEffects = CFE_BOLD;
	cf.dwMask = CFM_COLOR | CFM_BOLD;
	cf.crTextColor = m_iAColor;
	long start = ((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->GetTextLength();
	long end = start + WParam;
	OnReceive(WParam, LParam);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(start,-1);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSelectionCharFormat(cf);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(-1,-1);
}

void
CWatchComDlg::OnReceiveB(WPARAM WParam, LPARAM LParam)
{
	CString cResult;
	CString cTemp;
	CString cFormat;
	COleDateTime cNow = COleDateTime::GetCurrentTime();
	if (cNow.GetDay() < m_iPreviousDay)
	{
		OnButtonClear();
		m_iPreviousDay = cNow.GetDay();
	}
	cFormat = m_szBFileName;
	bool bHaveEscape;
	bHaveEscape = false;
	int i;
	if (strlen(m_szBFileName))
	{

		for (int iSourceIndex = 0; iSourceIndex < cFormat.GetLength(); iSourceIndex++)
		{
			if ((cFormat[iSourceIndex]=='%') && (!bHaveEscape))
				bHaveEscape = true;
			else if (bHaveEscape)
			{
				bHaveEscape = false;
				switch (cFormat[iSourceIndex]) {
				case 'P':
					for (i = 0; i < (int)strlen(m_szBPort); i++)
						if ((m_szBPort[i] >=0)  && (m_szBPort[i] <= '9')) cResult += m_szBPort[i];
					break;
				case 'y':
					cTemp.Format("%04d",cNow.GetYear());
					cResult += cTemp;
					break;
				case 'm':
					cTemp.Format("%02d",cNow.GetMonth());
					cResult += cTemp;
					break;
				case 'd':
					cTemp.Format("%02d",cNow.GetDay());
					cResult += cTemp;
					break;
				case 'H':
					cTemp.Format("%02d",cNow.GetHour());
					cResult += cTemp;
					break;
				case 'M':
					cTemp.Format("%02d",cNow.GetMinute());
					cResult += cTemp;
					break;
				case 'S':
					cTemp.Format("%02d",cNow.GetSecond());
					cResult += cTemp;
					break;
				default:
					cResult += cFormat[iSourceIndex];
				}
			}
			else
				cResult += cFormat[iSourceIndex];
		}
		if (cResult.FindOneOf("\\/?*:;><\"")<0)
		{
			CString cFilePathName;
			cFilePathName = m_szBDestination;
			cFilePathName += cResult;
			FILE * outfile = fopen(cFilePathName,"at");
			if (outfile)
			{
				for (int i = 0; i < (int)WParam; i++)
				{
					if (m_bBNewLine)
					{
						m_bBNewLine = false;
						fprintf(outfile,"%s ",cNow.Format("%Y\\%m\\%d %H:%M:%S"));
					}
					char ch = (*((char*)LParam+i));
					if ((m_cBPreviousChar == 0x0d) && (ch != 0x0a)) 
						fputc(0x0a,outfile);
					fputc(ch,outfile);
					if (ch == 0x0A) m_bBNewLine = true;
					m_cBPreviousChar = ch;
				}
				fclose(outfile);
			}
		}
	}

	CHARFORMAT cf;
	cf.cbSize=sizeof(cf);
	cf.dwEffects = CFE_BOLD;
	cf.dwMask = CFM_COLOR | CFM_BOLD;
	cf.crTextColor = m_iBColor;
	long start = ((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->GetTextLength();
	long end = start + WParam;
	OnReceive(WParam, LParam);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(start,-1);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSelectionCharFormat(cf);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(-1,-1);
}

void
CWatchComDlg::OnReceiveC(WPARAM WParam, LPARAM LParam)
{
	CString cResult;
	CString cTemp;
	CString cFormat;
	COleDateTime cNow = COleDateTime::GetCurrentTime();
	if (cNow.GetDay() < m_iPreviousDay)
	{
		OnButtonClear();
		m_iPreviousDay = cNow.GetDay();
	}
	cFormat = m_szBFileName;
//	GetDlgItemText(IDC_EDIT_LONGNAME,cFormat);
	bool bHaveEscape;
	bHaveEscape = false;
	int i;
	if (strlen(m_szCFileName))
	{
		for (int iSourceIndex = 0; iSourceIndex < cFormat.GetLength(); iSourceIndex++)
		{
			if ((cFormat[iSourceIndex]=='%') && (!bHaveEscape))
				bHaveEscape = true;
			else if (bHaveEscape)
			{
				bHaveEscape = false;
				switch (cFormat[iSourceIndex]) {
				case 'P':
					for (i = 0; i < (int)strlen(m_szCPort); i++)
						if ((m_szCPort[i] >=0)  && (m_szCPort[i] <= '9')) cResult += m_szCPort[i];
					break;
				case 'y':
					cTemp.Format("%04d",cNow.GetYear());
					cResult += cTemp;
					break;
				case 'm':
					cTemp.Format("%02d",cNow.GetMonth());
					cResult += cTemp;
					break;
				case 'd':
					cTemp.Format("%02d",cNow.GetDay());
					cResult += cTemp;
					break;
				case 'H':
					cTemp.Format("%02d",cNow.GetHour());
					cResult += cTemp;
					break;
				case 'M':
					cTemp.Format("%02d",cNow.GetMinute());
					cResult += cTemp;
					break;
				case 'S':
					cTemp.Format("%02d",cNow.GetSecond());
					cResult += cTemp;
					break;
				default:
					cResult += cFormat[iSourceIndex];
				}
			}
			else
				cResult += cFormat[iSourceIndex];
		}
		if (cResult.FindOneOf("\\/?*:;><\"")<0)
		{
			CString cFilePathName;
			cFilePathName = m_szCDestination;
			cFilePathName += cResult;
			FILE * outfile = fopen(cFilePathName,"at");
			if (outfile)
			{
				for (int i = 0; i < (int)WParam; i++)
				{
					if (m_bCNewLine)
					{
						m_bCNewLine = false;
						fprintf(outfile,"%s ",cNow.Format("%Y\\%m\\%d %H:%M:%S"));
					}
					char ch = (*((char*)LParam+i));
					if ((m_cCPreviousChar == 0x0d) && (ch != 0x0a)) 
						fputc(0x0a,outfile);
					fputc(ch,outfile);
					if (ch == 0x0A) m_bCNewLine = true;
					m_cCPreviousChar = ch;
				}
				fclose(outfile);
			}
		}
	}
	CHARFORMAT cf;
	cf.cbSize=sizeof(cf);
	cf.dwEffects = CFE_BOLD;
	cf.dwMask = CFM_COLOR | CFM_BOLD;
	cf.crTextColor = m_iCColor;
	long start = ((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->GetTextLength();
	long end = start + WParam;
	OnReceive(WParam, LParam);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(start,-1);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSelectionCharFormat(cf);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(-1,-1);
}

void
CWatchComDlg::OnReceiveD(WPARAM WParam, LPARAM LParam)
{
	CString cResult;
	CString cTemp;
	CString cFormat;
	COleDateTime cNow = COleDateTime::GetCurrentTime();
	if (cNow.GetDay() < m_iPreviousDay)
	{
		OnButtonClear();
		m_iPreviousDay = cNow.GetDay();
	}
	cFormat = m_szDFileName;
//	GetDlgItemText(IDC_EDIT_LONGNAME,cFormat);
	bool bHaveEscape;
	bHaveEscape = false;
	int i;
	if (strlen(m_szDFileName))
	{

		for (int iSourceIndex = 0; iSourceIndex < cFormat.GetLength(); iSourceIndex++)
		{
			if ((cFormat[iSourceIndex]=='%') && (!bHaveEscape))
				bHaveEscape = true;
			else if (bHaveEscape)
			{
				bHaveEscape = false;
				switch (cFormat[iSourceIndex]) {
				case 'P':
					for (i = 0; i < (int)strlen(m_szDPort); i++)
						if ((m_szDPort[i] >=0)  && (m_szDPort[i] <= '9')) cResult += m_szDPort[i];
					break;
				case 'y':
					cTemp.Format("%04d",cNow.GetYear());
					cResult += cTemp;
					break;
				case 'm':
					cTemp.Format("%02d",cNow.GetMonth());
					cResult += cTemp;
					break;
				case 'd':
					cTemp.Format("%02d",cNow.GetDay());
					cResult += cTemp;
					break;
				case 'H':
					cTemp.Format("%02d",cNow.GetHour());
					cResult += cTemp;
					break;
				case 'M':
					cTemp.Format("%02d",cNow.GetMinute());
					cResult += cTemp;
					break;
				case 'S':
					cTemp.Format("%02d",cNow.GetSecond());
					cResult += cTemp;
					break;
				default:
					cResult += cFormat[iSourceIndex];
				}
			}
			else
				cResult += cFormat[iSourceIndex];
		}
		if (cResult.FindOneOf("\\/?*:;><\"")<0)
		{
			CString cFilePathName;
			cFilePathName = m_szDDestination;
			cFilePathName += cResult;
			FILE * outfile = fopen(cFilePathName,"at");
			if (outfile)
			{
				for (int i = 0; i < (int)WParam; i++)
				{
					if (m_bDNewLine)
					{
						m_bDNewLine = false;
						fprintf(outfile,"%s ",cNow.Format("%Y\\%m\\%d %H:%M:%S"));
					}
					char ch = (*((char*)LParam+i));
					if ((m_cDPreviousChar == 0x0d) && (ch != 0x0a)) 
						fputc(0x0a,outfile);
					fputc(ch,outfile);
					if (ch == 0x0A) m_bDNewLine = true;
					m_cDPreviousChar = ch;
				}
				fclose(outfile);
			}
		}
	}
	CHARFORMAT cf;
	cf.cbSize=sizeof(cf);
	cf.dwEffects = CFE_BOLD;
	cf.dwMask = CFM_COLOR | CFM_BOLD;
	cf.crTextColor = m_iDColor;
	long start = ((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->GetTextLength();
	long end = start + WParam;
	OnReceive(WParam, LParam);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(start,-1);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSelectionCharFormat(cf);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(-1,-1);
}

CWatchComDlg::~CWatchComDlg()
{
	if(ComA)
	{
		ComA->UnRegister(0);
		//shutdown the com object's receiver
		ComA->DoStop();
		//get the com object to kill itself
		ComA->PostThreadMessage(IDC_COM_STOP,0,0);
		TerminateThread(ComA->m_hThread,0);
		::WaitForSingleObject(ComA->m_hThread,1000);
		delete ComA;
		//remove it from the com array
		ComA = NULL;

	}
	if(ComB)
	{
		ComB->UnRegister(0);
		//shutdown the com object's receiver
		ComB->DoStop();
		//get the com object to kill itself
		ComB->PostThreadMessage(IDC_COM_STOP,0,0);
		TerminateThread(ComB->m_hThread,0);
		::WaitForSingleObject(ComB->m_hThread,1000);
		delete ComB;
		//remove it from the com array
		ComB = NULL;
	}
	if(ComC)
	{
		ComC->UnRegister(0);
		//shutdown the com object's receiver
		ComC->DoStop();
		//get the com object to kill itself
		ComC->PostThreadMessage(IDC_COM_STOP,0,0);
		TerminateThread(ComC->m_hThread,0);
		::WaitForSingleObject(ComC->m_hThread,1000);
		delete ComC;
		//remove it from the com array
		ComC = NULL;
	}
	if(ComD)
	{
		ComD->UnRegister(0);
		//shutdown the com object's receiver
		ComD->DoStop();
		//get the com object to kill itself
		ComD->PostThreadMessage(IDC_COM_STOP,0,0);
		TerminateThread(ComD->m_hThread,0);
		::WaitForSingleObject(ComD->m_hThread,1000);
		delete ComD;
		//remove it from the com array
		ComD = NULL;
	}
}

void CWatchComDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else if (nID == IDM_COMA)
	{
		OnButtonA();
	}
	else if (nID == IDM_COMB)
	{
		OnButtonB();
	}
	else if (nID == IDM_COMC)
	{
		OnButtonC();
	}
	else if (nID == IDM_COMD)
	{
		OnButtonD();
	}
	else if (nID == IDM_CLEARLOG)
	{
		OnButtonClear();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWatchComDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWatchComDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWatchComDlg::OnButtonA() 
{
	// TODO: Add your control notification handler code here
	if (ComA)
	{
		ComA->UnRegister(0);
		//shutdown the com object's receiver
		ComA->DoStop();
		//get the com object to kill itself
		ComA->PostThreadMessage(IDC_COM_STOP,0,0);
		TerminateThread(ComA->m_hThread,0);
		::WaitForSingleObject(ComA->m_hThread,1000);
		delete ComA;
		//remove it from the com array
		ComA = NULL;
		SetDlgItemText(IDC_STATIC_COMA,"Com A: Not Set");
	}
	
	CSelect Select;
	Select.m_dBaudRate = m_dABaudRate;
	Select.m_dDataBits = m_dADataBits;
	Select.m_dStopBits = m_dAStopBits;

	strcpy(Select.m_szDestination, m_szADestination);
	strcpy(Select.m_szFileName, m_szAFileName);
	strcpy(Select.m_szPort,m_szAPort);

	switch (m_szAParity[0]) {
	case 'o':
	case 'O':
		Select.m_dParity = 0;
		break;
	case 'e':
	case 'E':
		Select.m_dParity = 1;
		break;
	case 'm':
	case 'M':
		Select.m_dParity = 2;
		break;
	default:
		Select.m_dParity = 3;
	}

	if (Select.DoModal() == IDOK) 
	{
		//Build a new A
		ComA = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		switch (Select.m_dParity) {
		case 0:
			strcpy(m_szAParity,"ODD");
			break;
		case 1:
			strcpy(m_szAParity,"EVEN");
			break;
		case 2:
			strcpy(m_szAParity,"MARK");
			break;
		default:
			strcpy(m_szAParity,"NONE");
		}

		char szTemp[64];
		strcpy(m_szADestination,Select.m_szDestination);
		WritePrivateProfileString("COM_A","FILELOCATION",m_szADestination,m_szIniFile);
		strcpy(m_szAFileName,Select.m_szFileName);
		WritePrivateProfileString("COM_A","FILENAME",m_szAFileName,m_szIniFile);
		strcpy(m_szAPort,Select.m_szPort);
		WritePrivateProfileString("COM_A","PORT",m_szAPort,m_szIniFile);
		WritePrivateProfileString("COM_A","PARITY",m_szAParity,m_szIniFile);
		m_dABaudRate = Select.m_dBaudRate;
		WritePrivateProfileString("COM_A","BAUD",itoa(m_dABaudRate,szTemp,10),m_szIniFile);
		m_dADataBits = Select.m_dDataBits;
		WritePrivateProfileString("COM_A","DATABITS",itoa(m_dADataBits,szTemp,10),m_szIniFile);
		m_dAStopBits = Select.m_dStopBits;
		WritePrivateProfileString("COM_A","STOPBITS",itoa(m_dAStopBits,szTemp,10),m_szIniFile);

		sprintf(szTemp,"Com A: %s, %d, %d, %d, %s",
			Select.m_szPort,
			Select.m_dBaudRate,
			Select.m_dDataBits,
			Select.m_dStopBits,
			m_szAParity);

		if (ComA->SetUpPort(m_szAPort,m_dABaudRate,
				m_dADataBits, m_dAStopBits,m_szAParity))
		{
			//connect to it
			ComA->DoSetMessage(1);
			ComA->Register(this);
			ComA->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMA,szTemp);
		}
		else
		{
			CString st("Could not set up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComA->DoStop();
			//get the com object to kill itself
			ComA->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComA->m_hThread,1000);
	//		TerminateThread(ComA->m_hThread,0);
			delete ComA;
			ComA = NULL;

			MessageBox(st,"WatchCom",MB_OK);
			SetDlgItemText(IDC_STATIC_COMA,"Com A: FAILED");
		}
	}
}

void CWatchComDlg::OnButtonB() 
{
	// TODO: Add your control notification handler code here
	if (ComB)
	{
		ComB->UnRegister(0);
		//shutdown the com object's receiver
		ComB->DoStop();
		//get the com object to kill itself
		ComB->PostThreadMessage(IDC_COM_STOP,0,0);
		::WaitForSingleObject(ComB->m_hThread,1000);
		TerminateThread(ComB->m_hThread,0);
		delete ComB;
		//remove it from the com array
		ComB = NULL;
		SetDlgItemText(IDC_STATIC_COMB,"Com B: Not Set");
	}
	
	CSelect Select;
	Select.m_dBaudRate = m_dBBaudRate;
	Select.m_dDataBits = m_dBDataBits;
	Select.m_dStopBits = m_dBStopBits;

	strcpy(Select.m_szDestination, m_szBDestination);
	strcpy(Select.m_szFileName, m_szBFileName);
	strcpy(Select.m_szPort,m_szBPort);

	switch (m_szBParity[0]) {
	case 'o':
	case 'O':
		Select.m_dParity = 0;
		break;
	case 'e':
	case 'E':
		Select.m_dParity = 1;
		break;
	case 'm':
	case 'M':
		Select.m_dParity = 2;
		break;
	default:
		Select.m_dParity = 3;
	}

	if (Select.DoModal() == IDOK)
	{

		//Build a new B
		ComB = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		char szTemp[64];
		switch (Select.m_dParity) {
		case 0:
			strcpy(m_szBParity,"ODD");
			break;
		case 1:
			strcpy(m_szBParity,"EVEN");
			break;
		case 2:
			strcpy(m_szBParity,"MARK");
			break;
		default:
			strcpy(m_szBParity,"NONE");
		}

		strcpy(m_szBDestination,Select.m_szDestination);
		WritePrivateProfileString("COM_B","FILELOCATION",m_szBDestination,m_szIniFile);
		strcpy(m_szBFileName,Select.m_szFileName);
		WritePrivateProfileString("COM_B","FILENAME",m_szBFileName,m_szIniFile);
		strcpy(m_szBPort,Select.m_szPort);
		WritePrivateProfileString("COM_B","PORT",m_szBPort,m_szIniFile);
		WritePrivateProfileString("COM_B","PARITY",m_szBParity,m_szIniFile);
		m_dBBaudRate = Select.m_dBaudRate;
		WritePrivateProfileString("COM_B","BAUD",itoa(m_dBBaudRate,szTemp,10),m_szIniFile);
		m_dBDataBits = Select.m_dDataBits;
		WritePrivateProfileString("COM_B","DATABITS",itoa(m_dBDataBits,szTemp,10),m_szIniFile);
		m_dBStopBits = Select.m_dStopBits;
		WritePrivateProfileString("COM_B","STOPBITS",itoa(m_dBStopBits,szTemp,10),m_szIniFile);

		sprintf(szTemp,"Com B: %s, %d, %d, %d, %s",
			Select.m_szPort,
			Select.m_dBaudRate,
			Select.m_dDataBits,
			Select.m_dStopBits,
			m_szBParity);

		if (ComB->SetUpPort(m_szBPort,m_dBBaudRate,
				m_dBDataBits, m_dBStopBits,m_szBParity))
		{
			//connect to it
			ComB->DoSetMessage(2);
			ComB->Register(this);
			ComB->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMB,szTemp);
		}
		else
		{
			CString st("Could not start up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComB->DoStop();
			//get the com object to kill itself
			ComB->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComB->m_hThread,1000);
	//		TerminateThread(ComB->m_hThread,0);
			delete ComB;
			ComB = NULL;

			MessageBox(st,"WatchCom",MB_OK);
			SetDlgItemText(IDC_STATIC_COMB,"Com B: FAILED");
		}
	}
}

void CWatchComDlg::OnButtonC() 
{
	// TODO: Add your control notification handler code here
	if (ComC)
	{
		ComC->UnRegister(0);
		//shutdown the com object's receiver
		ComC->DoStop();
		//get the com object to kill itself
		ComC->PostThreadMessage(IDC_COM_STOP,0,0);
		::WaitForSingleObject(ComC->m_hThread,1000);
		TerminateThread(ComC->m_hThread,0);
		delete ComC;
		//remove it from the com array
		ComC = NULL;
		SetDlgItemText(IDC_STATIC_COMC,"Com C: Not Set");
	}
	
	CSelect Select;
	Select.m_dBaudRate = m_dCBaudRate;
	Select.m_dDataBits = m_dCDataBits;
	Select.m_dStopBits = m_dCStopBits;

	strcpy(Select.m_szDestination, m_szCDestination);
	strcpy(Select.m_szFileName, m_szCFileName);
	strcpy(Select.m_szPort,m_szCPort);

	switch (m_szCParity[0]) {
	case 'o':
	case 'O':
		Select.m_dParity = 0;
		break;
	case 'e':
	case 'E':
		Select.m_dParity = 1;
		break;
	case 'm':
	case 'M':
		Select.m_dParity = 2;
		break;
	default:
		Select.m_dParity = 3;
	}

	if (Select.DoModal() == IDOK)
	{

		//Build a new B
		ComC = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		char szTemp[64];
		switch (Select.m_dParity) {
		case 0:
			strcpy(m_szCParity,"ODD");
			break;
		case 1:
			strcpy(m_szCParity,"EVEN");
			break;
		case 2:
			strcpy(m_szCParity,"MARK");
			break;
		default:
			strcpy(m_szCParity,"NONE");
		}

		strcpy(m_szCDestination,Select.m_szDestination);
		WritePrivateProfileString("COM_C","FILELOCATION",m_szCDestination,m_szIniFile);
		strcpy(m_szCFileName,Select.m_szFileName);
		WritePrivateProfileString("COM_C","FILENAME",m_szCFileName,m_szIniFile);
		strcpy(m_szCPort,Select.m_szPort);
		WritePrivateProfileString("COM_C","PORT",m_szCPort,m_szIniFile);
		WritePrivateProfileString("COM_C","PARITY",m_szCParity,m_szIniFile);
		m_dCBaudRate = Select.m_dBaudRate;
		WritePrivateProfileString("COM_C","BAUD",itoa(m_dCBaudRate,szTemp,10),m_szIniFile);
		m_dCDataBits = Select.m_dDataBits;
		WritePrivateProfileString("COM_C","DATABITS",itoa(m_dCDataBits,szTemp,10),m_szIniFile);
		m_dBStopBits = Select.m_dStopBits;
		WritePrivateProfileString("COM_C","STOPBITS",itoa(m_dCStopBits,szTemp,10),m_szIniFile);

		sprintf(szTemp,"Com C: %s, %d, %d, %d, %s",
			Select.m_szPort,
			Select.m_dBaudRate,
			Select.m_dDataBits,
			Select.m_dStopBits,
			m_szCParity);

		if (ComC->SetUpPort(m_szCPort,m_dCBaudRate,
				m_dCDataBits, m_dCStopBits,m_szCParity))
		{
			//connect to it
			ComC->DoSetMessage(3);
			ComC->Register(this);
			ComC->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMC,szTemp);
		}
		else
		{
			CString st("Could not start up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComC->DoStop();
			//get the com object to kill itself
			ComC->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComC->m_hThread,1000);
	//		TerminateThread(ComB->m_hThread,0);
			delete ComC;
			ComC = NULL;

			MessageBox(st,"WatchCom",MB_OK);
			SetDlgItemText(IDC_STATIC_COMC,"Com C: FAILED");
		}
	}
}

void CWatchComDlg::OnButtonD() 
{
	// TODO: Add your control notification handler code here
	if (ComD)
	{
		ComD->UnRegister(0);
		//shutdown the com object's receiver
		ComD->DoStop();
		//get the com object to kill itself
		ComD->PostThreadMessage(IDC_COM_STOP,0,0);
		::WaitForSingleObject(ComD->m_hThread,1000);
		TerminateThread(ComD->m_hThread,0);
		delete ComD;
		//remove it from the com array
		ComD = NULL;
		SetDlgItemText(IDC_STATIC_COMD,"Com D: Not Set");
	}
	
	CSelect Select;
	Select.m_dBaudRate = m_dDBaudRate;
	Select.m_dDataBits = m_dDDataBits;
	Select.m_dStopBits = m_dDStopBits;

	strcpy(Select.m_szDestination, m_szDDestination);
	strcpy(Select.m_szFileName, m_szDFileName);
	strcpy(Select.m_szPort,m_szDPort);

	switch (m_szDParity[0]) {
	case 'o':
	case 'O':
		Select.m_dParity = 0;
		break;
	case 'e':
	case 'E':
		Select.m_dParity = 1;
		break;
	case 'm':
	case 'M':
		Select.m_dParity = 2;
		break;
	default:
		Select.m_dParity = 3;
	}

	if (Select.DoModal() == IDOK)
	{

		//Build a new B
		ComD = (CSerial*)AfxBeginThread(RUNTIME_CLASS(CSerial));
		//set it up
		char szTemp[64];
		switch (Select.m_dParity) {
		case 0:
			strcpy(m_szDParity,"ODD");
			break;
		case 1:
			strcpy(m_szDParity,"EVEN");
			break;
		case 2:
			strcpy(m_szDParity,"MARK");
			break;
		default:
			strcpy(m_szDParity,"NONE");
		}

		strcpy(m_szDDestination,Select.m_szDestination);
		WritePrivateProfileString("COM_D","FILELOCATION",m_szDDestination,m_szIniFile);
		strcpy(m_szDFileName,Select.m_szFileName);
		WritePrivateProfileString("COM_D","FILENAME",m_szDFileName,m_szIniFile);
		strcpy(m_szDPort,Select.m_szPort);
		WritePrivateProfileString("COM_D","PORT",m_szDPort,m_szIniFile);
		WritePrivateProfileString("COM_D","PARITY",m_szDParity,m_szIniFile);
		m_dDBaudRate = Select.m_dBaudRate;
		WritePrivateProfileString("COM_D","BAUD",itoa(m_dDBaudRate,szTemp,10),m_szIniFile);
		m_dDDataBits = Select.m_dDataBits;
		WritePrivateProfileString("COM_D","DATABITS",itoa(m_dDDataBits,szTemp,10),m_szIniFile);
		m_dDStopBits = Select.m_dStopBits;
		WritePrivateProfileString("COM_D","STOPBITS",itoa(m_dDStopBits,szTemp,10),m_szIniFile);

		sprintf(szTemp,"Com D: %s, %d, %d, %d, %s",
			Select.m_szPort,
			Select.m_dBaudRate,
			Select.m_dDataBits,
			Select.m_dStopBits,
			m_szDParity);

		if (ComD->SetUpPort(m_szDPort,m_dDBaudRate,
				m_dDDataBits, m_dDStopBits,m_szDParity))
		{
			//connect to it
			ComD->DoSetMessage(4);
			ComD->Register(this);
			ComD->PostThreadMessage(IDC_COM_START,0,0);
			SetDlgItemText(IDC_STATIC_COMD,szTemp);
		}
		else
		{
			CString st("Could not start up port\n");
			st += szTemp;

			//shutdown the com object's receiver
			ComD->DoStop();
			//get the com object to kill itself
			ComD->PostThreadMessage(IDC_COM_STOP,0,0);
			::WaitForSingleObject(ComD->m_hThread,1000);
	//		TerminateThread(ComB->m_hThread,0);
			delete ComD;
			ComD = NULL;

			MessageBox(st,"WatchCom",MB_OK);
			SetDlgItemText(IDC_STATIC_COMD,"Com D: FAILED");
		}
	}
}

HBRUSH CWatchComDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	UINT index = pWnd->GetDlgCtrlID();
	if (index == IDC_STATIC_COMA)
	{
		pDC->SetTextColor(m_iAColor);
		pDC->SetBkColor(COLOR_BKGROUND);
	}
	if (index == IDC_STATIC_COMB)
	{
		pDC->SetTextColor(m_iBColor);
		pDC->SetBkColor(COLOR_BKGROUND);
	}
	if (index == IDC_STATIC_COMC)
	{
		pDC->SetTextColor(m_iCColor);
		pDC->SetBkColor(COLOR_BKGROUND);
	}
	if (index == IDC_STATIC_COMD)
	{
		pDC->SetTextColor(m_iDColor);
		pDC->SetBkColor(COLOR_BKGROUND);
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CWatchComDlg::OnButtonClear() 
{
	// TODO: Add your control notification handler code here
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(0,-1);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->ReplaceSel("",false);
	((CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT1))->SetSel(0,0);
}

void CWatchComDlg::OnButtonSave() 
{
	// TODO: Add your control notification handler code here
	CString text;
	GetDlgItemText(IDC_RICHEDIT1,text);
	FILE *outfile;
	CFileDialog FileDialog(FALSE,"rtf","",
	OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOREADONLYRETURN,
	"Rich Text Files (*.rtf)|*.rtf|All Files (*.*)|*.*||",this);
	if (FileDialog.DoModal()!=IDCANCEL)
	{
		CString filename = FileDialog.GetPathName();
		outfile = fopen(filename,"w");
		for (int i = 0; i < text.GetLength(); i++)
			fputc(text[i],outfile);
		fclose(outfile);
	}
}
void CWatchComDlg::OnSizing(UINT nSide, LPRECT lpRect)
{
	CRect cRect(lpRect);
	if (cRect.Height() < m_WindowRect.Height() || cRect.Width() < m_WindowRect.Width())
	{
		switch (nSide) {
		case WMSZ_TOP:
			lpRect->top = lpRect->bottom - m_WindowRect.Height();
			break;
		case WMSZ_BOTTOM:
			lpRect->bottom = lpRect->top + m_WindowRect.Height();
			break;
		case WMSZ_LEFT:
			lpRect->left = lpRect->right - m_WindowRect.Width();
			break;
		case WMSZ_RIGHT:
			lpRect->right = lpRect->left + m_WindowRect.Width();
			break;
		case WMSZ_BOTTOMLEFT:
			lpRect->bottom = lpRect->top + m_WindowRect.Height();
			lpRect->left = lpRect->right - m_WindowRect.Width();
			break;
		case WMSZ_BOTTOMRIGHT:
			lpRect->bottom = lpRect->top + m_WindowRect.Height();
			lpRect->right = lpRect->left + m_WindowRect.Width();
			break;
		case WMSZ_TOPLEFT:
			lpRect->top = lpRect->bottom - m_WindowRect.Height();
			lpRect->left = lpRect->right - m_WindowRect.Width();
			break;
		case WMSZ_TOPRIGHT:
			lpRect->top = lpRect->bottom - m_WindowRect.Height();
			lpRect->right = lpRect->left + m_WindowRect.Width();
			break;
		}
	}

	CDialog::OnSizing(nSide,lpRect);
}

void CWatchComDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	SetTimer(RESIZETIMER,200,NULL);
	
}

void CWatchComDlg::ResizeChildren()
{
	CRect rectClient,rectChart;
	GetClientRect(&rectClient);
	GetDlgItem(IDC_RICHEDIT1)->GetWindowRect(&rectChart);
	ScreenToClient(&rectChart);
	GetDlgItem(IDC_RICHEDIT1)->MoveWindow(
		rectChart.left,
		rectChart.top,
		rectClient.right - rectChart.left - rectChart.left,
		rectClient.bottom - rectChart.top - 10, true);
}

void CWatchComDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if (nIDEvent == RESIZETIMER)
	{
		ResizeChildren();
		KillTimer(RESIZETIMER);
		Invalidate();
	}
	
	CDialog::OnTimer(nIDEvent);
}
