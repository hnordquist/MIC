//-----------------------------------------------------------------------------
//
// EOSS - Electronic Optical Sealing System
//
// Sample Seal Reader
//
// (c) 2007 Dr. Neumann Consultants
// D-50259 Pulheim, Schiffgesweg 9, Germany
//
//-----------------------------------------------------------------------------
//
// This program uses the EOSS Crypto Dongle COM Server (TokCom.exe)
//
//-----------------------------------------------------------------------------


#include "stdafx.h"

#include "eoss.h"

int _tmain(int argc, _TCHAR* argv[])
{
	try
	{

	if (argc <= 1)
		return 0;

	ADDRESS Address = _ttoi(argv[1]);

	//CoInitializeEx(NULL, COINIT_MULTITHREADED);
	CoInitialize(NULL);
	//
	// comport object, constructor may throw an exception
	// 
	CComport Comport(1, 1000);

	//
	// crypto dongle object, constructor may throw an exception
	// 
	CDongle Dongle; 

	//
	// seal object
	// 
	CEoss Eoss(Address, &Comport, &Dongle);

	//
	// initialize challenge-response protocol
	//
	if (!Eoss.GetChallenge())
		return 1;

	//
	// log on
	// 
	if (!Eoss.Logon("STL", "GN"))
		return 2;

	//
	// get seal status
	//
	STATUS Status;
	if (!Eoss.GetStatus(&Status))
		return 3;

	if (Status.Flags & FLAG_FOOPEN)
		printf("\n\rseal wire is open");
	else
		printf("\n\rseal wire is closed");

	//
	// get log information
	//
	LOGINFO LogInfo;
	if (!Eoss.GetLogInfo(&LogInfo))
		return 4;

	//
	// get current seal log page
	//
	printf("\n\r\n\rseal wire events: %u", LogInfo.SealEvents);

	LOGPAGE LogPage;
	if (!Eoss.GetLogPage(&LogPage, LogInfo.SealLogCurrentPage))
		return 5;

	for (int i = 0; i < SEALEVENTS_PER_PAGE; i++)
	{
		if (!LogPage.SealLogPage.Entries[i].HalfDays &&
			 !LogPage.SealLogPage.Entries[i].Seconds)
			break;

		SYSTEMTIME SystemTime;
		EossToSystemTime(&SystemTime, &LogPage.SealLogPage.Entries[i]);

		printf("\n\r%.4u-%.2u-%.2u %.2u:%.2u:%.2u", 
				SystemTime.wYear, SystemTime.wMonth, SystemTime.wDay,
				SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond);

		if (i & 1)
			printf(" closed");
		else
			printf(" opened");
	}

	//
	// get current system log page
	//
	printf("\n\rsystem events: %u", LogInfo.SystemEvents);

	if (!Eoss.GetLogPage(&LogPage, LogInfo.SystemLogCurrentPage))
		return 6;

	for (int i = 0; i < SYSTEMEVENTS_PER_PAGE; i++)
	{
		if (!LogPage.SystemLogPage.Entries[i].Time.HalfDays && 
			 !LogPage.SystemLogPage.Entries[i].Time.Seconds)
			break;

		SYSTEMTIME SystemTime;
		EossToSystemTime(&SystemTime, &LogPage.SystemLogPage.Entries[i].Time);

		printf("\n\r%.4u-%.2u-%.2u %.2u:%.2u:%.2u", 
				SystemTime.wYear, SystemTime.wMonth, SystemTime.wDay,
				SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond);

		//
		// for an example on how to decode EOSS event codes,
		// please refer to EossReaderSealAndSystemEvents.xslt.
		// You can find the file in the Html folder in
		// the EOSS Reader installation directory
		// 
		printf(" %.5d", LogPage.SystemLogPage.Entries[i].Code);
	}

	//
	// log off
	//
	if (!Eoss.Logoff())
		return 7;

	} 
	catch (char * s)
	{
		printf(s);
	}

	return 0;
}

