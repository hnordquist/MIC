//-----------------------------------------------------------------------------
//
// EOSS - Electronic Optical Sealing System
//
// Sample Seal Reader
//
// (c) 2007 Dr. Neumann Consultants
// D-50259 Pulheim, Schiffgesweg 9, Germany
//
//-----------------------------------------------------------------------------

#include "stdafx.h"

#include "eoss.h"

#include "crc.h"

//-----------------------------------------------------------------------------

CEoss::CEoss(ADDRESS Address, CComport * pComport, CDongle * pDongle)
{
	m_pComport = pComport;
	m_pDongle = pDongle;
	m_Address = Address;
}

//-----------------------------------------------------------------------------

CEoss::~CEoss(void)
{
}

//-----------------------------------------------------------------------------
//
// send a package
// returns true on success 
//
bool CEoss::SendTo(PACKAGE * pPackage, int Length)
{
	FRAME Frame;

	Frame.Header.Receiver = m_Address;
	Frame.Header.Sender = 0;
	Frame.Header.Size = Length + (unsigned short)sizeof(Frame.Header) + 2;

	memcpy(&Frame.Package, pPackage, Length);

	unsigned short Crc = Crc16(&Frame, sizeof(Frame.Header) + Length, 0);

	int TotalLength = sizeof(Frame.Header) + Length;

	unsigned char * pTail = (unsigned char *)&Frame + TotalLength;

	*(unsigned short *)pTail = Crc;

	TotalLength += 2;

	return m_pComport->SendFrame((PBYTE)&Frame, TotalLength) == TotalLength;
}

//-----------------------------------------------------------------------------
//
// receive a package
// returns true on success
//
bool CEoss::RecvFrom(PACKAGE * pPackage, int * pLength)
{
	FRAME Frame;

	int Received = m_pComport->RecvFrame((PBYTE)&Frame, sizeof(FRAME));

	if (Received < (sizeof(Frame.Header) + 2))
		return false; // too few

	if (Frame.Header.Sender != m_Address)
		return false; // not from the seal

	if (Frame.Header.Receiver != 0)
		return false; // not for us

	Received -= 2;

	unsigned short Crc = *(unsigned short *)((unsigned char *)&Frame + Received);

	if (Crc16(&Frame, Received, 0) != Crc)
		return false; // crc error

	Received -= sizeof(Frame.Header);
	
	memcpy(pPackage, &Frame.Package, Received);

	*pLength = Received;

	return true; 
}

//-----------------------------------------------------------------------------
//
// get initial challenge token
// returns true on success
//
bool CEoss::GetChallenge(void)
{
	PACKAGE Package;
	Package.Type = PCK_GETCHALLENGE;

	bool Result = SendTo(&Package, sizeof(Package.Type));
	if (!Result) return Result;

	int Length;
	Result = RecvFrom(&Package, &Length);
	if (!Result) return Result;

	if (Length != sizeof(CHALLENGE))
		return false;

	if (Package.Type != PCK_CHALLENGE)
		return false;

	m_KeysetNumber = Package.Challenge.KeySetNumber;
	m_KeysetTime = Package.Challenge.KeySetTime.HalfDays * 43200 + (43200 - Package.Challenge.KeySetTime.Seconds);

	memcpy(ChallengeToken, Package.Challenge.Token, sizeof(DESBLOCK));

	return true;
}

//-----------------------------------------------------------------------------
// 
// send request and receive reply
// returns true on success
//
bool CEoss::Reqply(PACKAGE * pPackage, int DataBytesToSend, int DataBytesExpected)
{
	pPackage->Type = PCK_REQUEST;

	// authorization
	if (!m_pDongle->Authorize(m_KeysetNumber, m_KeysetTime,
		ChallengeToken, &pPackage->Request, DataBytesToSend / sizeof(DESBLOCK)))
		return false;
	
	// encryption (by means of 'decryption' direction)
	if (!m_pDongle->Decipher(m_KeysetNumber, m_KeysetTime, 
		(DESBLOCK *)&pPackage->Request.Data, DataBytesToSend / sizeof(DESBLOCK)))
		return false;

	if (!SendTo(pPackage, sizeof(pPackage->Request) - sizeof(pPackage->Request.Data) + DataBytesToSend))
		return false;

	int Length;
	if (!RecvFrom(pPackage, &Length))
		return false;

	if (pPackage->Type != PCK_REPLY)
		return false;

	if (DataBytesExpected)
	{
		if (Length != (DataBytesExpected + sizeof(pPackage->Reply.Type) + sizeof(pPackage->Reply.Token) + sizeof(pPackage->Reply.Authentication)))
			return false;
		
		// decryption		
		if (!m_pDongle->Decipher(m_KeysetNumber, m_KeysetTime,
			(DESBLOCK *)&pPackage->Reply.Data, DataBytesExpected / sizeof(DESBLOCK)))
			return false;
				
		// identification 
		if (!m_pDongle->Identify(m_KeysetNumber, m_KeysetTime,
			ChallengeToken, &pPackage->Reply, DataBytesExpected / sizeof(DESBLOCK)))
			return false;
	}
	else
	{
		if (Length != (sizeof(pPackage->Reply.Type) + sizeof(pPackage->Reply.Token)))
			return false;
	}

	memcpy(ChallengeToken, pPackage->Reply.Token, sizeof(DESBLOCK));

	return true;
}

//-----------------------------------------------------------------------------
//
// put up to 3 captital letters into 16 bits
// (there's no error checking here...)
// 
unsigned short MakeID(char * szOperator)
{
	unsigned short Id = 0;
	while (char Letter = *szOperator++)
	{
		Letter -= 'A';
		Id *= 27;
		Id += Letter + 1;
	}
	return Id;
}

//-----------------------------------------------------------------------------
// 
// create log-on event
// returns true on success
//
bool CEoss::Logon(char * szOperator1, char * szOperator2)
{
	PACKAGE Package;

	Package.Request.Command = CMD_LOGON;
	Package.Request.Parameter = 0;

	Package.Request.Data.Initials.Operator1 = MakeID(szOperator1);
	Package.Request.Data.Initials.Operator2 = MakeID(szOperator2);

	return Reqply(&Package, sizeof(INITIALS), 0);
}

//-----------------------------------------------------------------------------
// 
// get seal status
// returns true on success
//
bool CEoss::GetStatus(STATUS * pStatus)
{
	PACKAGE Package;

	Package.Request.Command = CMD_STATUS;
	Package.Request.Parameter = 0;

	if (Reqply(&Package, 0, sizeof(STATUS)))
	{
		memcpy(pStatus, &Package.Reply.Data.Status, sizeof(STATUS));
		
		return true;
	}
	return false;
}

//-----------------------------------------------------------------------------
// 
// get log information
// returns true on success
//
bool CEoss::GetLogInfo(LOGINFO * pLogInfo)
{
	PACKAGE Package;

	Package.Request.Command = CMD_LOGINFO;
	Package.Request.Parameter = 0;

	if (Reqply(&Package, 0, sizeof(LOGINFO)))
	{
		memcpy(pLogInfo, &Package.Reply.Data.LogInfo, sizeof(LOGINFO));
		
		return true;
	}
	return false;
}

//-----------------------------------------------------------------------------
// 
// get one log page
// returns true on success
//
bool CEoss::GetLogPage(LOGPAGE * pLogPage, unsigned char PageNumber)
{
	PACKAGE Package;

	Package.Request.Command = CMD_LOGPAGE;
	Package.Request.Parameter = PageNumber;

	if (Reqply(&Package, 0, sizeof(LOGPAGE)))
	{
		memcpy(pLogPage, &Package.Reply.Data.Page, sizeof(LOGPAGE));
		
		return true;
	}
	return false;
}

//-----------------------------------------------------------------------------
// 
// create logoff event
// returns true on success
//
bool CEoss::Logoff(void)
{
	PACKAGE Package;

	Package.Request.Command = CMD_LOGOFF;
	Package.Request.Parameter = 0;

	return Reqply(&Package, 0, 0);
}

//-----------------------------------------------------------------------------

void EossToSystemTime(SYSTEMTIME * pSystemTime, EOSSTIME * pEossTime)
{
	SYSTEMTIME SystemTime;
	
	SystemTime.wYear = 2000;
	SystemTime.wMonth = 1;
	SystemTime.wDay = 1;
	SystemTime.wHour = 0;
	SystemTime.wMinute = 0;
	SystemTime.wSecond = 0;
	SystemTime.wMilliseconds = 0;

	ULONGLONG FileTime;
	
	SystemTimeToFileTime(&SystemTime, (LPFILETIME)&FileTime);

	ULONGLONG EossTime = pEossTime->HalfDays * 43200 + (43200 - pEossTime->Seconds);

	FileTime += (EossTime * 10000000);
	
	FileTimeToSystemTime((LPFILETIME)&FileTime, pSystemTime);
}