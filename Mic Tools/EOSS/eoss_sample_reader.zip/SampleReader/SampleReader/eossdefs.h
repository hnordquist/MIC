//-----------------------------------------------------------------------------
//
// EOSS - Electronic Optical Sealing System
//
// Sample Seal Reader
//
// (c) 2007 Dr. Neumann Consultants
// D-50259 Pulheim, Schiffgesweg 9, Germany
//
//-----------------------------------------------------------------------------

#pragma once

#define CMD_LOGON 'L'
#define CMD_LOGOFF 'O'
#define CMD_TIME 'T'
#define CMD_STATUS 'S'
#define CMD_SETUP 'U'
#define CMD_LOGINFO 'I'
#define CMD_LOGPAGE 'P'
#define CMD_KEYSET 'K'
#define CMD_WRITEPAD 'W'
#define CMD_READPAD 'R'
#define CMD_ERASE 'E'
#define CMD_HASH 'H'

#define PCK_GETCHALLENGE 'G'
#define PCK_CHALLENGE 'C'
#define PCK_REQUEST 'Q'
#define PCK_REPLY 'R'
#define PCK_DENIAL 'D'
#define PCK_TRIGGER 'T'
#define PCK_INQUIRY 'I'

#pragma pack(push)
#pragma pack(1)

typedef unsigned long ADDRESS;

typedef struct tagTIME {
    unsigned short HalfDays;
    unsigned short Seconds;
} EOSSTIME;

typedef unsigned char DESBLOCK[8];

typedef struct tagGETCHALLENGE {
    unsigned short Type;
} GETCHALLENGE;

typedef struct tagCHALLENGE {
    unsigned short Type;
    unsigned long Seal;         // seal serial number
    unsigned long KeySetNumber; // key-set number
    EOSSTIME      KeySetTime;   // date and time of key-set generation
    unsigned char Version1;     // major version number
    unsigned char Version2;     // minor version standard
    DESBLOCK Token;
} CHALLENGE;

typedef struct tagTIMEDATA {
    unsigned short HalfDays;
    unsigned short Seconds;
    unsigned long Reserved;
} TIMEDATA;

typedef struct tagINITIALS {
   unsigned short Operator1;  // ID of operator 1
   unsigned short Operator2;  // ID of operator 2 or zero
   unsigned short Reserved2;
   unsigned short Reserved3;
} INITIALS;

#define FLAG_FOOPEN  1
#define FLAG_FOFAIL  2
#define FLAG_HOPEN	4
#define FLAG_SHORT	8
#define FLAG_BROKEN 16

typedef struct tagSTATUS {
   ADDRESS Seal;
   EOSSTIME Time;

   unsigned short Operator1;
   unsigned short Operator2;
   unsigned char Flags;
   signed char Temperature;
   unsigned char EmergencyBattery;
   unsigned char MainBattery;

   unsigned short FlashWarnings;
   unsigned short FlashErrors;
   unsigned short MajoWarnings;
   unsigned short MajoErrors;

   unsigned short EPROMCrc16;
   unsigned char BatID[8];
   char BatteryType[8];
   unsigned short BatteryMfg;
   unsigned long BatteryConsumed;

   unsigned short EBatteryMfg;
   unsigned long EBatteryConsumed;
   unsigned short BatteryInstalled;

   unsigned short EBatteryInstalled;
   signed short T0Offset;
   signed short F0Offset;
   unsigned short LaserThreshold;

   unsigned short Laser500uW;
   unsigned short LaserPeak;
   unsigned short LaserAdjDate;
   char LaserId[16];
   unsigned long VacossAttachments;
   unsigned char VacossEnabled;

   unsigned char Reserved[5];
} STATUS;

#define PAGE_SIZE 64
#define PAGES_TOTAL 8192 / PAGE_SIZE

typedef struct tagPAGEHEADER {
   unsigned short Seal;
   unsigned char Log;
   unsigned char Page;
   EOSSTIME Time;
   DESBLOCK Authenticator;
} PAGEHEADER;

typedef PAGEHEADER * PPAGEHEADER;

typedef EOSSTIME SEALEVENT;

typedef struct tagSYSTEMEVENT {
	EOSSTIME Time;
	unsigned short Code;
} SYSTEMEVENT;

typedef struct tagSOHRECORD {
      unsigned short Date;
      signed char MinTemperature;
      signed char MaxTemperature;
      unsigned char EmergencyBattery;
      unsigned char MainBattery;
      unsigned char OnBatteries;
      unsigned char MVEvents;
} SOHRECORD;

#define SEALEVENTS_PER_PAGE (PAGE_SIZE - sizeof(PAGEHEADER)) / sizeof(SEALEVENT)
#define SYSTEMEVENTS_PER_PAGE (PAGE_SIZE - sizeof(PAGEHEADER)) / sizeof(SYSTEMEVENT)
#define SOHRECORDS_PER_PAGE (PAGE_SIZE - sizeof(PAGEHEADER)) / sizeof(SOHRECORD)

typedef struct {
	PAGEHEADER Header;
	SEALEVENT Entries[SEALEVENTS_PER_PAGE];
} SEALLOGPAGE;

typedef struct tagSYSTEMLOGPAGE {
	PAGEHEADER Header;
	SYSTEMEVENT Entries[SYSTEMEVENTS_PER_PAGE];
} SYSTEMLOGPAGE;

typedef struct tagSOHLOGPAGE {
	PAGEHEADER Header;
	SOHRECORD Entries[SOHRECORDS_PER_PAGE];
} SOHLOGPAGE;

typedef union {
	SEALLOGPAGE SealLogPage;
	SYSTEMLOGPAGE SystemLogPage;
	SOHLOGPAGE SoHLogPage; 
} LOGPAGE;

typedef struct tagLOGBOOKINFO {
   unsigned long SealEvents;
   unsigned char SealLogFirstPage;
   unsigned char SealLogLastPage;
   unsigned char SealLogStartPage;
   unsigned char SealLogCurrentPage;

   unsigned long SystemEvents;
   unsigned char SystemLogFirstPage;
   unsigned char SystemLogLastPage;
   unsigned char SystemLogStartPage;
   unsigned char SystemLogCurrentPage;

   unsigned short SoHRecords;
   unsigned char SoHLogFirstPage;
   unsigned char SoHLogLastPage;
   unsigned char SoHLogStartPage;
   unsigned char SoHLogCurrentPage;

   unsigned char TotalPadPages;
   unsigned char ExStatusFlags;

   unsigned long KeysetNumber;
   EOSSTIME KeysetTime;
} LOGINFO;

typedef union tagREQUEST_DATA {
    TIMEDATA Time;
    INITIALS Initials;
    unsigned char Page[PAGE_SIZE];
    DESBLOCK HashKey;   // the hash key to be used for program memory verification
} REQUEST_DATA;

typedef union tagREPLY_DATA {
    STATUS Status;
    LOGINFO LogInfo;
    unsigned char Page[PAGE_SIZE];
    DESBLOCK KeyedHash; // keyed hash value over the entire program memory
} REPLY_DATA;

typedef struct tagREQUEST {
   unsigned short Type;
   DESBLOCK Authorization;
   unsigned char Command;
   unsigned char Parameter;
   REQUEST_DATA Data;
} REQUEST;

typedef struct tagREPLY {
   unsigned short Type;
   DESBLOCK Token;
   DESBLOCK Authentication;
   REPLY_DATA Data;
} REPLY;

typedef struct tagDENIAL {
   unsigned short Type;
   DESBLOCK Token;
   unsigned short Error;
} DENIAL;

typedef struct tagTRIGGER {
   unsigned short Type;
   unsigned char Flags;
   unsigned char Reserved;
} TRIGGER;

typedef union tagPACKAGE {
    unsigned short Type;
    GETCHALLENGE GetChallenge;
    CHALLENGE Challenge;
    REQUEST Request;
    REPLY Reply;
    DENIAL Denial;
    TRIGGER Trigger;
} PACKAGE;

typedef struct tagHEADER {
   ADDRESS Receiver;
   ADDRESS Sender;
   unsigned short Size;
} HEADER;

typedef struct tagFRAME {
   HEADER Header;
   PACKAGE Package;
	short ______crc;	// for sizeof() only!
} FRAME;

#pragma pack(pop)