//-----------------------------------------------------------------------------
//
// EOSS - Electronic Optical Sealing System
//
// Sample Seal Reader
//
// (c) 2007 Dr. Neumann Consultants
// D-50259 Pulheim, Schiffgesweg 9, Germany
//
//-----------------------------------------------------------------------------

#pragma once

#include "eossdefs.h"

#include "comport.h"

#include "dongle.h"

class CEoss
{
private:
	CComport * m_pComport;
	CDongle * m_pDongle;
	ADDRESS m_Address;
public:
	CEoss(ADDRESS Address, CComport * pComport, CDongle * pDongle);
	~CEoss(void);
private:
	DESBLOCK ChallengeToken;
	LONG m_KeysetNumber;
	LONG m_KeysetTime;
private:
	bool SendTo(PACKAGE * pPackage, int Length);
	bool RecvFrom(PACKAGE * pPackage, int * pLength);
	bool Reqply(PACKAGE * pPackage, int DataBytesToSend, int DataBytesExpected);
public:
	bool GetChallenge(void);
	bool Logon(char * szOperator1, char * szOperator2);
	bool GetStatus(STATUS * pStatus);
	bool GetLogInfo(LOGINFO * pLogInfo);
	bool GetLogPage(LOGPAGE * pLogPage, unsigned char PageNumber);
	bool Logoff(void);
};

#include <windows.h>

void EossToSystemTime(SYSTEMTIME * pSystemTime, EOSSTIME * pEossTime);